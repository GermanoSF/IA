package ia_missionarios;

import java.util.LinkedList;
import java.util.List;

import busca.BuscaLargura;
import busca.BuscaProfundidade;
import busca.Estado;
import busca.MostraStatusConsole;
import busca.Nodo;
import java.util.Arrays;

public class IA_Missionarios implements Estado {
    
    @Override
    public String getDescricao() {
        return " Problema dos missionarios e canibais.... ";
    }
    private char[] missionarios = new char[3];
    private char[] canibais = new char[3];
    final String op; // operacao que gerou o estado
    
    /** construtor para o estado, recebe cada valor de atributo */
    public IA_Missionarios(char[] missionarios, char[] canibais, String op) {    
        this.missionarios = missionarios;
        this.canibais = canibais;
        this.op = op;
    }

    /**
     * verifica se o estado final foi atingido
     */
    @Override
    public boolean ehMeta() {
        return Arrays.equals(this.missionarios, new char[]{'f','f','f'}) && Arrays.equals(this.canibais, new char[]{'f','f','f'});
    }

    
    // verifica se e valido o estado
    public boolean ehValido(char[] missionarios, char[] canibais){
        
        int m = 0 , c = 0, m1 = 0, c1 = 0;
        
        for (char mi : missionarios){
            
            if (mi == 'i') m1+=1;
            
        }
        
        for (char ca : canibais){
            
            if (ca == 'i') c1+=1;
            
        }
               
        for (char mi : missionarios){
            
            if (mi == 'f') m+=1;
            
        }
        
        for (char ca : canibais){
            
            if (ca == 'f') c+=1;
            
        }
        
        if (m > 0 && m1 > 0) return m>=c && m1>=c1;
        if (m>0) return m>=c;
        if (m1>0) return m1>=c1;
        
        return false;
         
    }
    
    /**
     * Custo para geracao do estado
     */
    @Override
    public int custo() {
        return 1;
    }
    
    /**
     * gera uma lista de sucessores do nodo.
     * @return visitados
     */
    @Override
    public List<Estado> sucessores() {
        List<Estado> visitados = new LinkedList<Estado>(); // a lista de sucessores
        
        levar2c(visitados);
        levar2m(visitados);
        levar1dc(visitados);
        
        return visitados;
    }
    
    private void levar2c(List<Estado> visitados){
        
        char[] canibais = this.canibais;
        
        if (canibais[0] == 'i' && canibais[1] == 'f') return;
        
        for (int i = 0; i<canibais.length;i++){
            
            if ((canibais[i] == 'f' && i-2 >= 0) || (i == canibais.length -1 && canibais[i] == 'f')){
                
                canibais[i-1] = 'f';
                canibais[i-2] = 'f';
                
            }
            
            if (i == canibais.length -1 && canibais[i] == 'i'){
                
                canibais[i] = 'f';
                canibais[i-1] = 'f';
                
            }
            
        }
        
        if  (ehValido(missionarios,this.canibais)){
            
            IA_Missionarios novo = new IA_Missionarios(this.missionarios.clone(),canibais.clone(),"Levar 2 canibais");
            visitados.add(novo);
            
        }
        
    }
    
    private void levar2m(List<Estado> visitados){
        
        char[] missionarios = this.missionarios;
        
        if (missionarios[0] == 'i' && missionarios[1] == 'f') return;
        
        for (int i = 0; i<missionarios.length;i++){
            
            if ((missionarios[i] == 'f' && i-2 >= 0) || (i == missionarios.length -1 && missionarios[i] == 'f')){
                
                missionarios[i-1] = 'f';
                missionarios[i-2] = 'f';
                
            }
            
            if (i == missionarios.length -1 && missionarios[i] == 'i'){
                
                missionarios[i] = 'f';
                missionarios[i-1] = 'f';
                
            }
            
        }
        
        if  (ehValido(missionarios,this.canibais)){
            
            IA_Missionarios novo = new IA_Missionarios(missionarios.clone(),this.canibais.clone(),"Levar 2 missionarios");
            visitados.add(novo);
            
        }
        
    }
    
    private void levar1dc(List<Estado> visitados){
        
        int parada1 = 0, parada2 = 0;
        char[] missionarios = this.missionarios;
        char[] canibais = this.canibais;
        
        if (missionarios[0] == 'f') return;
        if (canibais[0] == 'f') return;
        
        for (int i = missionarios.length -1; parada1 == 0;i--){
            
            if (missionarios[i] == 'i'){
                
                missionarios[i] = 'f';
                
                parada1 = 1;
                
            }
            
        }
        
        for (int i = canibais.length -1; parada2 == 0;i--){
            
            if (canibais[i] == 'i'){
                
                canibais[i] = 'f';
                
                parada2 = 1;
                
            }
            
        }
        
        if  (ehValido(missionarios,canibais)){
            
            IA_Missionarios novo = new IA_Missionarios(missionarios.clone(),canibais.clone(),"Levar 1 missionario e 1 canibal");
            visitados.add(novo);
            
        }
        
    }
    
    @Override
    public String toString() {
        return op + "\n";
    }
    
    
    public static void main(String[] a) {
        
        IA_Missionarios estadoInicial = new IA_Missionarios(new char[]{'i','i','i'},new char[]{'i','i','i'},"Estado inicial (3 missionarios e 3 canibais do lado inicial)");
        
        // chama busca em Profundidade
        System.out.println("busca em ....");
        
        Nodo n = new BuscaProfundidade(new MostraStatusConsole()).busca(estadoInicial);
        
        if (n == null) {
            System.out.println("sem solucao!");
        } else {
            System.out.println("solucao:\n" + n.montaCaminho() + "\n\n");
        }
    }
}
