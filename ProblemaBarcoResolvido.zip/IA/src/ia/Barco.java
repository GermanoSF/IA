package ia;

import java.util.LinkedList;
import java.util.List;

import busca.BuscaLargura;
import busca.BuscaProfundidade;
import busca.Estado;
import busca.MostraStatusConsole;
import busca.Nodo;
import java.util.HashSet;
import java.util.Stack;
import javax.swing.JOptionPane;

public class Barco implements Estado {
    
    @Override
    public String getDescricao() {
        return " Problema das Jarras.... ";
    }
    final char homem,carneiro,lobo,alface;
    final String op; // operacao que gerou o estado
    
    /** construtor para o estado, recebe cada valor de atributo */
    public Barco(char lobo, char alface,char homem,char carneiro, String op) {    
        this.homem = homem;
        this.carneiro = carneiro;
        this.lobo = lobo;
        this.alface = alface;
        this.op = op;
    }

    /**
     * verifica se o estado final foi atingido
     */
    @Override
    public boolean ehMeta() {
        return this.homem == 'f' && this.carneiro == 'f' && this.alface == 'f' && this.lobo == 'f';
    }

    public boolean ehValido(char lobo, char alface, char homem, char carneiro){
        
        return !(lobo == carneiro && homem != carneiro)&&!(alface == carneiro && homem != carneiro);
        
    }
    
    /**
     * Custo para geracao do estado
     */
    @Override
    public int custo() {
        return 1;
    }
    
    /**
     * gera uma lista de sucessores do nodo.
     * @return visitados
     */
    @Override
    public List<Estado> sucessores() {
        List<Estado> visitados = new LinkedList<Estado>(); // a lista de sucessores
        
        levarHomem(visitados);
        levarLobo(visitados);
        levarAlface(visitados);
        levarCarneiro(visitados);
        
        return visitados;
    }
    
//    private boolean ehValido(Stack origem, Stack destino) {
//        if (origem.isEmpty() ||
//            (!origem.isEmpty() && !destino.isEmpty() && (int)origem.peek() > (int)destino.peek())) {
//            return false;
//        }
//        
//        return true;
//    }
    
    private void levarHomem(List<Estado> visitados) {

            if (ehValido(this.lobo,this.alface,'f',this.carneiro)){
                Barco novo = new Barco(this.lobo, this.alface,'f',this.carneiro, "levar homem");
                if (!visitados.contains(novo))visitados.add(novo);
            }
            
    }
    
    private void levarLobo(List<Estado> visitados) {

            if (ehValido('f',this.alface,this.homem,this.carneiro)){
                Barco novo = new Barco('f', this.alface,this.homem,this.carneiro, "levar lobo");
                if (!visitados.contains(novo))visitados.add(novo);
            }
            
    }
    
    private void levarAlface(List<Estado> visitados) {

            if (ehValido(this.lobo,'f',this.homem,this.carneiro)){
                Barco novo = new Barco(this.lobo, 'f',this.homem,this.carneiro, "levar alface");
                if (!visitados.contains(novo))visitados.add(novo);
            }

    }
    
    private void levarCarneiro(List<Estado> visitados) {
        
        if (ehValido(this.lobo,this.alface,this.homem,'f')){
                Barco novo = new Barco(this.lobo, this.alface,this.homem,'f', "levar carneiro");
                if (!visitados.contains(novo))visitados.add(novo);
            }
        
    }
    
    /**
     * verifica se um estado e igual a outro
     * (usado para poda)
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof Barco) {
            Barco e = (Barco)o;
            return this.carneiro == e.carneiro &&
                   this.lobo == e.lobo&&
                   this.homem == e.homem &&
                   this.alface == e.alface;
        }
        return false;
    }
    
    /** 
     * retorna o hashCode do estado
     * (usado para poda, conjunto de fechados)
     */
    @Override
    public int hashCode() {
        return (""+this.carneiro + this.lobo + this.homem + this.alface).hashCode();
    }
    
    @Override
    public String toString() {
        return "Lados-> Homem: " + this.homem + " Carneiro: " + this.carneiro + " Alface: " + this.alface + " lobo: " + this.lobo + " Operacao: " + op + "\n";
    }
    
    
    public static void main(String[] a) {
        
        Barco estadoInicial = new Barco('i','i','i','i', "estado inicial, todos lado esquerdo(i)");
        
        // chama busca em largura
        System.out.println("busca em ....");
        
        Nodo n = new BuscaLargura(new MostraStatusConsole()).busca(estadoInicial);
        
        if (n == null) {
            System.out.println("sem solucao!");
        } else {
            System.out.println("solucao:\n" + n.montaCaminho() + "\n\n");
        }
    }
}