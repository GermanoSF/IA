package classesSudoku;

import java.util.List;
import busca.Estado;
import java.util.LinkedList;

public class SudokuIA implements Estado {
    
    @Override
    public String getDescricao() {
        return "Sudoku";
    }
    List<Integer> auxValor = new LinkedList<>();
    Integer lc[][] = new Integer[9][9];
    Integer colocarN,auxL,auxC,valor;
    final String op; // operacao que gerou o estado
    
    /** construtor para o estado, recebe cada valor de atributo */
    public SudokuIA(List<Integer> v, String op) {
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                this.lc[i][j] = 0;
                
            }
            
        }
        
        if (!v.isEmpty()){
            for (Integer valor : v){

                this.valor = valor/100;
                this.auxL = ((valor-valor/100*100)/10)-1;
                this.auxC = (valor-valor/10*10)-1;

                this.lc[auxL][auxC] = this.valor;

            }
        }
        
        this.op = op;
    }
    
    /**
     * verifica se o estado final foi atingido
     */
    @Override
    public boolean ehMeta() {
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                if (this.lc[i][j] == 0) return false;
                
            }
            
        }
        
        return true;
    }
    
    /**
     * Custo para geracao do estado
     */
    @Override
    public int custo() {
        return 1;
    }
    
    /**
     * gera uma lista de sucessores do nodo.
     * @return visitados
     */
    @Override
    public List<Estado> sucessores() {
        List<Estado> visitados = new LinkedList<Estado>(); // a lista de sucessores
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                if (this.lc[i][j] == 0){
                    
                    for (int a = 100; a < 1000; a += 100){
                        
                        this.colocarN = a + (i+1)*10 + (j+1);
                        
                        if (ehValido(this.colocarN)){
                            
                            this.auxValor.clear();
                            
                            for (int m=0;m<9;m++){

                                for (int n=0;n<9;n++){

                                    if (this.lc[m][n] != 0) this.auxValor.add(this.lc[m][n]*100+(m+1)*10+(n+1));

                                }

                            }

                            this.auxValor.add(colocarN);

                            SudokuIA novo = new SudokuIA(this.auxValor,colocarN.toString());

                            visitados.add(novo);
                            
                        }
                        
                    }
                    
                    return visitados;
                    
                }
                
            }
            
        }
        
        return visitados;
    }
    
    private boolean ehValido(Integer valor) {
        
        this.valor = valor/100;
        this.auxL = ((valor-valor/100*100)/10)-1;
        this.auxC = (valor-valor/10*10)-1;
        
        if (auxL<3){
            
            if (auxC<3){
                
                for (int i=0;i<3;i++){
                    
                    for (int j=0;j<3;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=3 && auxC<6){
                
                for (int i=0;i<3;i++){
                    
                    for (int j=3;j<6;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=6){
                
                for (int i=0;i<3;i++){
                    
                    for (int j=6;j<9;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            
        }
        if (auxL>=3 && auxL<6){
            
            if (auxC<3){
                
                for (int i=3;i<6;i++){
                    
                    for (int j=0;j<3;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=3 && auxC<6){
                
                for (int i=3;i<6;i++){
                    
                    for (int j=3;j<6;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=6){
                
                for (int i=3;i<6;i++){
                    
                    for (int j=6;j<9;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            
        }
        if (auxL>=6){
            
            if (auxC<3){
                
                for (int i=6;i<9;i++){
                    
                    for (int j=0;j<3;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=3 && auxC<6){
                
                for (int i=6;i<9;i++){
                    
                    for (int j=3;j<6;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            if (auxC>=6){
                
                for (int i=6;i<9;i++){
                    
                    for (int j=6;j<9;j++){
                        
                        if (this.lc[i][j] == this.valor) return false;
                        
                    }
                    
                }
                
            }
            
        }
        
        for (int i = 0; i < 9; i++){
            
            if (this.lc[auxL][i] == this.valor) return false;
            
        }
        
        for (int i = 0; i < 9; i++){
            
            if (this.lc[i][auxC] == this.valor) return false;
            
        }
        
        return true;
    }
        
    /**
     * verifica se um estado e igual a outro
     * (usado para poda)
     */
    @Override
    public boolean equals(Object obj) {
        
        SudokuIA o = (SudokuIA) obj;

        for (int i=0;i<9;i++){
            for (int j=0;j<9;j++){
                if (o.lc[i][j]!=this.lc[i][j]) return false;
            }
        }
        
        return true;
        
    }
    
    /** 
     * retorna o hashCode do estado
     * (usado para poda, conjunto de fechados)
     */
//    @Override
//    public int hashCode() {
//        return ...;
//    }
    
    @Override
    public String toString() {
        return this.op;
    }
 
}
