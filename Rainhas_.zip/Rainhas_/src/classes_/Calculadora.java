/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author laboratorio
 */
public class Calculadora {
    
    public static List<String> calcular(int numeroRainhas,int tentativasE){
    
        List<String> tabuleiroP = new ArrayList<>();
        List<Rainha> rainhas = new ArrayList<>();
        
        int metadeT;
        
        if (numeroRainhas%2 == 0) metadeT = numeroRainhas/2;
        else metadeT = numeroRainhas/2 +1;
        
        if (numeroRainhas%2 == 0){
            
            do{

                if (tentativasE<metadeT){
                    
                    rainhas.add(new Rainha(0,tentativasE));
                    
                }
                else{
                    
                    rainhas.clear();
                    
                }

            }while(tabuleiroP.isEmpty());
        }
        else{
            
            do{

                if (tentativasE<=metadeT){
                    
                    rainhas.add(new Rainha(0,tentativasE));
                    
                }
                else{
                    
                    rainhas.clear();
                    
                }

            }while(tabuleiroP.isEmpty());
            
        }
        
        return tabuleiroP;
    
    }
    
}
