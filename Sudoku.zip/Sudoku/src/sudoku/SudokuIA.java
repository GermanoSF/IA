import java.util.LinkedList;
import java.util.List;

import busca.BuscaLargura;
import busca.BuscaProfundidade;
import busca.Estado;
import busca.MostraStatusConsole;
import busca.Nodo;
import java.util.HashSet;
import java.util.Stack;
import javax.swing.JOptionPane;

public class SudokuIA implements Estado {
    
    @Override
    public String getDescricao() {
        return "Sudoku";
    }
    List<Integer> auxValor;
    Integer lc[][] = new Integer[9][9];
    Integer colocarN,auxL,auxC,valor;
    final String op; // operacao que gerou o estado
    
    /** construtor para o estado, recebe cada valor de atributo */
    public SudokuIA(List<Integer> v, String op) {
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                this.lc[i][j] = 0;
                
            }
            
        }
        
        for (Integer valor : v){
            
            this.valor = valor/100;
            this.auxL = (valor-valor/100*100)/10;
            this.auxC = valor-valor/10*10;

            this.lc[auxL][auxC] = this.valor;
        
        }
        
        this.op = op;
    }
    
    /**
     * verifica se o estado final foi atingido
     */
    @Override
    public boolean ehMeta() {
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                if (this.lc[i][j] == 0) return false;
                
            }
            
        }
        
        return true;
    }
    
    /**
     * Custo para geracao do estado
     */
    @Override
    public int custo() {
        return 1;
    }
    
    /**
     * gera uma lista de sucessores do nodo.
     * @return visitados
     */
    @Override
    public List<Estado> sucessores() {
        List<Estado> visitados = new LinkedList<Estado>(); // a lista de sucessores
        
        colocar1(visitados);
        colocar2(visitados);
        colocar3(visitados);
        colocar4(visitados);
        colocar5(visitados);
        colocar6(visitados);
        colocar7(visitados);
        colocar8(visitados);
        colocar9(visitados);
        
        return visitados;
    }
    
    private boolean ehValido(Integer valor) {
        
        this.valor = valor/100;
        this.auxL = (valor-valor/100*100)/10;
        this.auxC = valor-valor/10*10;
        
        if (this.lc[auxL][auxC]!=0) return false;
        
        for (int i = 0; i < 9; i++){
            
            if (this.lc[auxL][i] == this.valor) return false;
            
        }
        
        for (int i = 0; i < 9; i++){
            
            if (this.lc[i][auxC] == this.valor) return false;
            
        }
        
        return true;
    }
    
    private void colocar1(List<Estado> visitados) {
        
        this.auxValor.clear();
        
        for (int i = 0; i < 9; i++){
            
            for (int j = 0; j < 9; j++){
                
                this.colocarN = 100+(i*10)+j;
                
                if (ehValido(this.colocarN)){
                    
                    for (int l = 0; l < 9; l++){
                        
                        for (int m = 0; m < 9; m++){
                            
                            if (this.lc[l][m]!=0) this.auxValor.add(this.lc[l][m]*100+l*10+m);
                            
                        }
                        
                    }

                    SudokuIA novo = new SudokuIA(this.auxValor,colocarN.toString());
                    
                    visitados.add(novo);
                    
                }
                
            }
                
        }
        
    }
    
    /**
     * verifica se um estado e igual a outro
     * (usado para poda)
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof SudokuIA) {
            SudokuIA e = (SudokuIA)o;
            return this.torre1.equals(e.torre1) &&
                   this.torre2.equals(e.torre2) &&
                   this.torre3.equals(e.torre3);
        }
        return false;
    }
    
    /** 
     * retorna o hashCode do estado
     * (usado para poda, conjunto de fechados)
     */
    @Override
    public int hashCode() {
        return (""+this.torre1 + this.torre2 + this.torre3).hashCode();
    }
    
    @Override
    public String toString() {
        return "" + this.torre1 + this.torre2 + this.torre3  + " -> " + op + "\n";
    }
    
    
    public static void main(String[] a) {
        int discos = Integer.parseInt(JOptionPane.showInputDialog(null, "Quantos discos?"));
        if (discos == 0) System.exit(0);
        
        Stack t1 = new Stack();
        Stack t2 = new Stack();
        Stack t3 = new Stack();
        
        for (;discos > 0; discos--) {
            t1.push(discos);
        }
        
        SudokuIA estadoInicial = new SudokuIA(t1, t2, t3, "estado inicial");
        
        // chama busca em largura
        System.out.println("busca em ....");
        
        Nodo n = new BuscaProfundidade(new MostraStatusConsole()).busca(estadoInicial);
        
        if (n == null) {
            System.out.println("sem solucao!");
        } else {
            System.out.println("solucao:\n" + n.montaCaminho() + "\n\n");
        }
    }
}
