
import java.util.Random;
/**
 * Classe que contém as letras do alfabeto no atributo letras (minúsculas e sem acento). Além do método de gerarPalavra()
 * @author alexandrezamberlan
 */
public class Util {

    /**
     * Atributo de classe que armazena todos as letras do alfabeto (minúsculas e sem acento)
     */
    private static int[] rota = new int[9];
    /**
     * Atributo de classe para guardar o tamanho do alfabeto
     */
    private static int tamanho = rota.length;
    
    /**
     * Método de classe que recebe a quantidade de caracteres que deve gerar a palavra
     * @param n quantidade de letras que a palavra gerada terá
     * @return uma palavra gerada aleatoriamente
     */
    public static int[] gerarRota() {

        Random gerador = new Random();

        for (int i = 0; i < tamanho; i++) {
            rota[i]=gerador.ints(1,tamanho+1).findFirst().getAsInt();
        }
        return rota.clone();
    }
}