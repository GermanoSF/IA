package ia;

import java.util.LinkedList;
import java.util.List;

import busca.BuscaLargura;
import busca.BuscaProfundidade;
import busca.Estado;
import busca.MostraStatusConsole;
import busca.Nodo;
import java.util.HashSet;
import java.util.Stack;
import javax.swing.JOptionPane;

public class Jarras implements Estado {
    
    @Override
    public String getDescricao() {
        return " Problema das Jarras.... ";
    }
    final Stack jarra1,jarra2;
    final String op; // operacao que gerou o estado
    
    /** construtor para o estado, recebe cada valor de atributo */
    public Jarras(Stack jarra1, Stack jarra2, String op) {
        this.jarra1 = jarra1;
        this.jarra2 = jarra2;
        this.op = op;
    }

    /**
     * verifica se o estado final foi atingido
     */
    @Override
    public boolean ehMeta() {
        return (this.jarra1.size() == 2 && this.jarra2.isEmpty())||(this.jarra2.size() == 2 && this.jarra1.isEmpty());
    }
    
    /**
     * Custo para geracao do estado
     */
    @Override
    public int custo() {
        return 1;
    }
    
    /**
     * gera uma lista de sucessores do nodo.
     * @return visitados
     */
    @Override
    public List<Estado> sucessores() {
        List<Estado> visitados = new LinkedList<Estado>(); // a lista de sucessores
        
        esvaziarJarra1(visitados);
        esvaziarJarra2(visitados);
        encherJarra1(visitados);
        encherJarra2(visitados);
        colocarJ1_J2(visitados);
        colocarJ2_J1(visitados);
        
        return visitados;
    }
    
//    private boolean ehValido(Stack origem, Stack destino) {
//        if (origem.isEmpty() ||
//            (!origem.isEmpty() && !destino.isEmpty() && (int)origem.peek() > (int)destino.peek())) {
//            return false;
//        }
//        
//        return true;
//    }
    
    private void esvaziarJarra1(List<Estado> visitados) {

            Jarras novo = new Jarras(new Stack(), (Stack)this.jarra2.clone(), "Esvaziar jarra 1");
            visitados.add(novo);
            
    }
    
    private void esvaziarJarra2(List<Estado> visitados) {

            Jarras novo = new Jarras((Stack)this.jarra1.clone(), new Stack(), "Esvaziar jarra 2");
            visitados.add(novo);
    }
    
    private void encherJarra1(List<Estado> visitados) {

            Stack cloneJ1 = (Stack) this.jarra1.clone();
        
            while (cloneJ1.size()<4){
                
                cloneJ1.push(1);
                
            }
        
            Jarras novo = new Jarras(cloneJ1, (Stack)this.jarra2.clone(), "Encher jarra 1");
            visitados.add(novo);

    }
    
    private void encherJarra2(List<Estado> visitados) {
        
        Stack cloneJ2 = (Stack) this.jarra2.clone();
        
        while (cloneJ2.size()<3){
                
            cloneJ2.push(1);
                
        }
        
        Jarras novo = new Jarras((Stack)this.jarra1.clone(), cloneJ2, "Encher jarra 2");
        visitados.add(novo);
        
    }
    
    private void colocarJ1_J2(List<Estado> visitados) {

        Stack cloneJ1 = (Stack) this.jarra1.clone();
        Stack cloneJ2 = (Stack) this.jarra2.clone();
            
        while (cloneJ2.size()<3&&!cloneJ1.isEmpty()){
                
            cloneJ1.pop();
            cloneJ2.push(1);
                
        }
        
        Jarras novo = new Jarras(cloneJ1,cloneJ2, "colocar jarra 1 em jarra 2");
        visitados.add(novo);
        
    }
    
    private void colocarJ2_J1(List<Estado> visitados) {
        
        Stack cloneJ1 = (Stack) this.jarra1.clone();
        Stack cloneJ2 = (Stack) this.jarra2.clone();
            
        while (cloneJ1.size()<4&&!cloneJ2.isEmpty()){
                
            cloneJ1.push(1);
            cloneJ2.pop();
                
        }
            
        Jarras novo = new Jarras(cloneJ1,cloneJ2, "colocar jarra 2 em jarra 1");
        visitados.add(novo);
            
    }
    /**
     * verifica se um estado e igual a outro
     * (usado para poda)
     */
    @Override
    public boolean equals(Object o) {
        if (o instanceof Jarras) {
            Jarras e = (Jarras)o;
            return this.jarra1.equals(e.jarra1) &&
                   this.jarra2.equals(e.jarra2);
        }
        return false;
    }
    
    /** 
     * retorna o hashCode do estado
     * (usado para poda, conjunto de fechados)
     */
    @Override
    public int hashCode() {
        return (""+this.jarra1 + this.jarra2).hashCode();
    }
    
    @Override
    public String toString() {
        return op + "\n";
    }
    
    
    public static void main(String[] a) {
        
        Jarras estadoInicial = new Jarras(new Stack(), new Stack(), "estado inicial (2 jarras zeradas)");
        
        // chama busca em largura
        System.out.println("busca em ....");
        
        Nodo n = new BuscaLargura(new MostraStatusConsole()).busca(estadoInicial);
        
        if (n == null) {
            System.out.println("sem solucao!");
        } else {
            System.out.println("solucao:\n" + n.montaCaminho() + "\n\n");
        }
    }
}