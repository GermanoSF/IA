package example;

// Environment code for project almoxarifado

import jason.asSyntax.*;
import jason.environment.*;
import jason.asSyntax.parser.*;

import java.text.ParseException;
import java.util.Random;

import java.util.logging.*;

public class Env extends Environment {

    private Logger logger = Logger.getLogger("almoxarifado."+Env.class.getName());

    private String gerar(){

        Random gerador = new Random();

        if (gerador.nextInt(2) == 0) return "peq";

        return "med";

    }

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        super.init(args);
        String peca = new String(gerar());
        try {
            addPercept(ASSyntax.parseLiteral("peca("+peca+")"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean executeAction(String agName, Structure action) {

        String funcao = action.getFunctor().toString();
        String param = action.getTerm(0).toString();

        if (agName.equals("r1") && funcao.equals("guardar") && param.equals("peq")) {
            logger.info(agName+ " esta guardando a peça " + param);
            try {
                removePercept(ASSyntax.parseLiteral(new String("peca("+param+")")));
            } catch (Exception e) {
                e.printStackTrace();
            }
             
        }

        if (agName.equals("r2") && funcao.equals("guardar") && param.equals("med")) {
            logger.info(agName+ " esta guardando a peça " + param);
            try {
                removePercept(ASSyntax.parseLiteral(new String("peca("+param+")")));
            } catch (Exception e) {
                e.printStackTrace();
            }
             
        }

        try{

            Thread.sleep(2000);
            addPercept(ASSyntax.parseLiteral(new String("peca("+gerar()+")")));

        } catch (Exception e){}

        return true; // the action was executed with success
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
}
