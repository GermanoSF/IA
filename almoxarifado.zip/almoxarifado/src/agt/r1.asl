viagens(5).
guarda(peq).

!start.

+!start : viagens(Qtd) & Qtd > 0 & guarda(Tipo) <- .print("Estou ativo e posso guardar ",Qtd," pecas do tipo ",Tipo).

+peca(Tamanho) : guarda(Tamanho) & viagens(Qtd) & Qtd > 0 <- 
                                                            .print("estou guardando peca do tipo ",Tamanho); 
                                                            guardar(Tamanho); 
                                                            -viagens(Qtd); 
                                                            NovaQtd = Qtd -1;
                                                            +viagens(NovaQtd);
                                                            .print("peca do tipo ",Tamanho," guardada").
